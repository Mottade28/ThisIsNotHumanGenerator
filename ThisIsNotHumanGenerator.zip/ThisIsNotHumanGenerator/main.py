#--Setup
from selenium import webdriver
from random import randint
from pathlib import Path
import os, time
driver = webdriver.PhantomJS(executable_path='res/phantomjs-2.1.1-windows/bin/phantomjs')
driver.get('https://thispersondoesnotexist.com/')




def create_profile(Nprofile):

    
    path_firstname = "res/FirstName_LastName/first_names.txt"
    path_lastname = "res/FirstName_LastName/last_names.txt"
    for I in range(0, Nprofile):

        
        driver.refresh()
        driver.refresh()
        
        x = randint(1, 21827)
        y = randint(1, 98365)
        f = open(path_firstname, 'r', encoding='utf8')
        g = open(path_lastname, 'r', encoding='utf8')

        first_name = f.readlines()
        first_name = str(first_name[x])
        last_name = g.readlines()
        last_name = str(last_name[y])

        directory_name = first_name.strip() + "_" + last_name.strip()
        os.chdir("results/")
        os.system("mkdir " + directory_name)
        




        
        directory = first_name.strip() +"_"+ last_name.strip()
        png = ".png"
        namefile = str(I)
        path_screenshot =  directory + "/" + namefile + png  
                          
        driver.refresh()
        driver.refresh()
        driver.save_screenshot(path_screenshot)
        print("A profile has been generated...")
        os.chdir('../')







x = input("Type the number of profiles ")
    
create_profile(int(x))
print('Task completed ! You can see the result in the "results" directory')
time.sleep(2)






